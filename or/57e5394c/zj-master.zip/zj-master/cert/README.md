该目录存放 HTTPS 证书，每个域名使用独立的目录。

`cert.conf` 文件被 `nginx.conf` 引用，保存 HTTPS 证书路径。